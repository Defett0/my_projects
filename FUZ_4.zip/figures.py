import numpy as np
import matplotlib.pyplot as plt
import imageio
from scipy.ndimage import zoom

def load_matrices(file_path, num_matrices=101, matrix_size=(10, 10)):
    """Wczytuje macierze z pliku tekstowego."""
    with open(file_path, "r") as file:
        lines = [line.strip() for line in file if line.strip()]
    
    matrix_height = len(lines) // num_matrices
    matrices = []
    for i in range(num_matrices):
        start = i * matrix_height
        end = (i + 1) * matrix_height
        matrix = np.array([[int(num) for num in line.split()] for line in lines[start:end]])
        matrices.append(matrix)
    
    return matrices

def create_gif(matrices, output_path, upscale_factor=20, duration=0.5):
    """Tworzy GIF z macierzy, zwiększając ich rozdzielczość."""
    color_map = {
        0: [255, 255, 255],  # Biały
        1: [0, 0, 255],      # Niebieski
        2: [255, 0, 0]       # Czerwony
    }
    
    frames = []
    for matrix in matrices:
        img_array = np.array([[color_map[val] for val in row] for row in matrix], dtype=np.uint8)
        high_res_img = zoom(img_array, (upscale_factor, upscale_factor, 1), order=0)  # Powiększenie obrazu

        # Przycinamy, jeśli powiększenie dodało przesunięcia
        target_size = (matrix.shape[0] * upscale_factor, matrix.shape[1] * upscale_factor, 3)
        high_res_img = high_res_img[:target_size[0], :target_size[1], :]

        frames.append(high_res_img)

    imageio.mimsave(output_path, frames, duration=duration)

# Wczytanie i generowanie GIF-a
matrices = load_matrices("matrix01.dat")
create_gif(matrices, "alfa01.gif")
matrices = load_matrices("matrix02.dat")
create_gif(matrices, "alfa02.gif")
matrices = load_matrices("matrix03.dat")
create_gif(matrices, "alfa03.gif")

data = [np.loadtxt(f"SIR0{i+1}.dat") for i in range(9)]
data = np.array(data)  # Teraz to tablica 3D o wymiarach (9, N, 2)

plt.figure(figsize=(8, 6))
for i in range(9):
    plt.plot(data[i, :, 0], data[i, :, 1])  # Iterujemy po indeksach

plt.grid()
plt.title("S(t) beta=0.2")
plt.legend([f"$\\alpha$=0.{i+1}" for i in range(9)])  # Automatyczne generowanie legendy
plt.savefig("S_beta02.pdf")

plt.figure(figsize=(8, 6))
for i in range(9):
    plt.plot(data[i, :, 0], data[i, :, 2])  # Iterujemy po indeksach

plt.grid()
plt.title("I(t) beta=0.2")
plt.legend([f"$\\alpha$=0.{i+1}" for i in range(9)])  # Automatyczne generowanie legendy
plt.savefig("I_beta02.pdf")

plt.figure(figsize=(8, 6))
for i in range(9):
    plt.plot(data[i, :, 0], data[i, :, 3])  # Iterujemy po indeksach

plt.grid()
plt.title("R(t) beta=0.2")
plt.legend([f"$\\alpha$=0.{i+1}" for i in range(9)])  # Automatyczne generowanie legendy
plt.savefig("R_beta02.pdf")



