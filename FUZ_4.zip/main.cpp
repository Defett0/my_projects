#include <iostream>
#include <vector>
#include <fstream>
#include <cstdlib>
#include <ctime>
#include <iomanip>
#include <sstream>

#define N 60

using namespace std;

int main(){
    double alfa[9]={0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9}, beta=0.2;
    int tries=0, S=0,I=0,R=0;
    vector<vector<int>> SIR(N, vector<int>(N, 0));
    vector<vector<int>> newSIR(N, vector<int>(N, 0));

    srand(time(NULL));
    rand();

     
    vector<ofstream> matrices(3);
    for (int i = 0; i < 3; ++i) {
        ostringstream filename;
        filename << "matrix" << setw(2) << setfill('0') << (i + 1) << ".dat";
        matrices[i].open(filename.str());
    }
    vector<ofstream> files(9);
    for (int i = 0; i < 9; ++i) {
        ostringstream filename;
        filename << "SIR" << setw(2) << setfill('0') << (i + 1) << ".dat";
        files[i].open(filename.str());
    }
   
    for(int a=0;a<9;a++){
        SIR.assign(N,vector<int>(N,0));
        newSIR.assign(N,vector<int>(N,0));
        SIR[N/2][N/2] = 1;
        for(int t=0; t<=100; t++){
            for(int i=0; i<N; i++){
                for(int j=0; j<N; j++){
                    if(SIR[i][j]==0){
                        for(int k=-1;k<=1;k++){
                            for(int l=-1;l<=1;l++){
                                int ni=(i+k+N)%N; 
                                int nj=(j+l+N)%N;
                                if(SIR[ni][nj]==1){
                                    tries++;
                                }
                            }
                        }
                        for(int p=0;p<tries;p++){
                            if((double)rand()/RAND_MAX<alfa[a]){
                                newSIR[i][j]=1;
                            }
                        }
                        tries = 0;
                        S++;
                    } else if(SIR[i][j]==1){
                        if((double)rand()/RAND_MAX < beta){
                            newSIR[i][j]=2;
                        } else {
                            newSIR[i][j]=1;
                        }
                        I++;
                    } else {
                        newSIR[i][j]=2;
                        R++;
                    }
                }
            }
            files[a] << t << " " << S << " " << I << " " << R << endl;
            S=0;
            I=0;
            R=0;
            SIR=newSIR;
            if(a<3){
                for(int i=0; i<N; i++){
                    for(int j=0; j<N; j++){
                        matrices[a] << SIR[i][j] << " ";
                    }
                    matrices[a] << endl;
                }
                matrices[a] << endl << endl;
            }
        }
    }
}