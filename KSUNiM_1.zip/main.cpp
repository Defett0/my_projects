#define _USE_MATH_DEFINES

#include <iostream>
#include <vector>
#include <fstream>
#include <iomanip>
#include <string>
#include <cmath>
#include "eigen-3.4.0/Eigen/Eigenvalues"

#define Eh 27.211
#define n 9
#define res 10 
#define wx (0.08/Eh)
#define wy (0.6/Eh)
#define ms 0.24
#define alfax (1./(wx*ms))
#define alfay (1./(wy*ms))
#define dx (1./0.0529)  
#define a (dx*(n-1)/2)
#define dxres (2*a/(n*res-1))

using namespace std;

double phi_calc(double x, double y, int k) {
    int i=k/n,j=k%n; 
    double xk=-a+i*dx;
    double yk=-a+j*dx;
    return 1.0/sqrt(sqrt(M_PI*alfax)*sqrt(M_PI*alfay))*exp(-pow(x-xk,2)/(2.*alfax))*exp(-pow(y-yk,2)/(2.*alfay));
}

void fill(Eigen::MatrixXd &S, Eigen::MatrixXd &H, Eigen::MatrixXd &K, Eigen::MatrixXd &V, double omegax, double omegay) {
    double alphax=1./(omegax*ms);  
    double alphay=1./(omegay*ms);
    
    for(int k=0;k<n*n;k++) {
        int ik=k/n;
        int jk=k%n;
        double xk=-a+ik*dx;
        double yk=-a+jk*dx;
    
        for(int l=0;l<n*n;l++) {
            int il=l/n;
            int jl=l%n;
            double xl=-a+il*dx;
            double yl=-a+jl*dx;
            S(k,l) = exp(-pow(xk-xl,2)/(4.*alphax)-pow(yk-yl,2)/(4.*alphay));
            K(k,l) = -1./(2*ms)*(((pow(xk-xl,2)-2*alphax)/(4*alphax*alphax))+((pow(yk-yl,2)-2*alphay)/(4*alphay*alphay)))*S(k,l);
            V(k,l) = ms/2.*((omegax*omegax/4.)*(pow(xk+xl,2)+2*alphax)+(omegay*omegay/4.)*(pow(yk+yl,2)+2*alphay))*S(k,l);
            H(k,l) = K(k,l)+V(k,l);
        }
    }
}

void psi_calc(vector<vector<double>> &psi, const Eigen::VectorXd &coeff) {
    for (int i=0;i<n*res;i++) {
        for (int j=0;j<n*res;j++) {
            psi[i][j]=0.0;
        }
    }
    
    for (int i=0;i<n*res;i++) {
        double x=-a+i*dxres;
        for (int j=0;j<n*res;j++) {
            double y=-a+j*dxres;
            for (int k=0;k<n*n;k++) {
                psi[i][j]+=coeff[k]*phi_calc(x,y,k);
            }
        }
    }
}

int main() {
    // Task 1
    vector<int> ks={0,8,9};
    
    for(int k:ks){
        ofstream file("phi"+to_string(k)+".dat");
        for (int i=0;i<n*res;i++){
            double x=-a+i*dxres;
            for (int j=0;j<n*res;j++) {
                double y=-a+j*dxres;
                file << x*0.0529 << " " << y*0.0529 << " " << phi_calc(x,y,k) << endl;
            }
        }
    }

    // Task 2
    Eigen::MatrixXd S(n*n,n*n), H(n*n,n*n), K(n*n,n*n), V(n*n,n*n);
    fill(S,H,K,V,wx,wy);
    Eigen::GeneralizedSelfAdjointEigenSolver<Eigen::MatrixXd> sol(H,S);

    // Task 3
    for(int e=0;e<6;e++) {
        ofstream file("psi"+to_string(e)+".dat");
        vector<vector<double>> psi(n*res,vector<double>(n*res)); 
        psi_calc(psi, sol.eigenvectors().col(e));
        
        for (int i=0;i<n*res;i++) {
            double x=-a+i*dxres;
            for (int j=0;j<n*res;j++) {
                double y=-a+j*dxres;
                file << x*0.0529 << " " << y*0.0529 << " " << psi[i][j]*psi[i][j] << endl;
            }
        }
    }
    vector<double> omegax;
    for(int i=0;i<101;i++){
        omegax.push_back(0.005*i/Eh);
    }
    
    vector<vector<double>> psi(n*res,vector<double>(n*res)); 
    ofstream energy("e.dat");
    for(int j=0;j<101;j++){
        fill(S,H,K,V,omegax[j],wy);
        Eigen::GeneralizedSelfAdjointEigenSolver<Eigen::MatrixXd> solit(H,S);
        energy << omegax[j]*Eh << " ";
        for(int i=0;i<10;i++){
            energy << solit.eigenvalues()[i]*Eh << " ";
        }
        energy << endl;
    }
}