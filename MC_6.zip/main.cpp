#define _USE_MATH_DEFINES
#include <iostream>
#include <fstream>
#include <cmath>
#include <vector>
#include <utility>
#include <cstdlib>
#include <ctime>
#include <string>

using namespace::std;

void vector_rotation(double tx, double ty, double tz, double & x, double & y, double & z, double teta){
	double p0,p1,p2,p3;
	double q0,q1,q2,q3;
	double r0,r1,r2,r3;
	
	double t=sqrt(tx*tx+ty*ty+tz*tz);
	double cs=cos(teta/2);
	double sn=sin(teta/2);
	
	p0=cs;
	p1=tx/t*sn;
	p2=ty/t*sn;
	p3=tz/t*sn;
	
	r0=0.;
	r1=x;
	r2=y;
	r3=z;
	
	q0=r0*p0-r1*(-p1)-r2*(-p2)-r3*(-p3);
	q1=r1*p0+r0*(-p1)-r3*(-p2)+r2*(-p3);
	q2=r2*p0+r3*(-p1)+r0*(-p2)-r1*(-p3);
	q3=r3*p0-r2*(-p1)+r1*(-p2)+r0*(-p3);
	
	r0=p0*q0-p1*q1-p2*q2-p3*q3;
	r1=p1*q0+p0*q1-p3*q2+p2*q3;
	r2=p2*q0+p3*q1+p0*q2-p1*q3;
	r3=p3*q0-p2*q1+p1*q2+p0*q3;
	
	x=r1;
	y=r2;
	z=r3;
	
	
	return;
}

void particle_translation(double & x1,double & y1, double & x2,double & y2, 
				  double xr,double yr, double Rr, double xa,double ya, double Ra, 
				  int & exist ,double & length)
{
	double a,b,c,delta,beta1,beta2,alfa1,alfa2,alfa;
    a=pow(x2-x1,2)+pow(y2-y1,2);
    b=2*( (x2-x1)*(x1-xa)+(y2-y1)*(y1-ya) );
    c=pow(x1-xa,2)+pow(y1-ya,2)-pow(Ra,2);
    delta=b*b-4*a*c;
    if(delta>=0){
        beta1=(-b-sqrt(delta))/2/a;
        beta2=(-b+sqrt(delta))/2/a;
        if(beta1>=0 && beta1<=1 || beta2>=0 && beta2<=1) exist=0; 
    }
	
	alfa=-1.0; 
	      
    a=pow(x2-x1,2)+pow(y2-y1,2);
    b=2*( (x2-x1)*(x1-xr)+(y2-y1)*(y1-yr) );
    c=pow(x1-xr,2)+pow(y1-yr,2)-pow(Rr,2);
    delta=b*b-4*a*c;
    if(delta>=0){
        alfa1=(-b-sqrt(delta))/2/a;
        alfa2=(-b+sqrt(delta))/2/a;
        if(alfa1>=0 && alfa1 <=1){
            alfa=alfa1;
        }else if(alfa2>=0 && alfa2 <=1){
            alfa=alfa2;
        }
    }
	
	if(alfa<0){
		x1=x2;
		y1=y2;
		length=0;
		return;
	} else{
		double norm;
		double x3,y3,z3;
		x3=x1+alfa*(x2-x1); 
		y3=y1+alfa*(y2-y1);
		z3=0.;
		
		double x13=x1-x3; 
		double y13=y1-y3;
		double z13=0;
		norm=sqrt(pow(x13,2)+pow(y13,2)+pow(z13,2));
		x13=x13/norm;
		y13=y13/norm;
		z13=z13/norm;
		
		double tx=0-x3; 
		double ty=0-y3;
		double tz=0-z3;
		
		vector_rotation(tx,ty,tz,x13,y13,z13,M_PI);
		
		
		length=sqrt(pow(x2-x3,2)+pow(y2-y3,2)); 
		
		x1=x3+x13*1.0E-6; 
		y1=y3+y13*1.0E-6;
		
		x2=x3+length*x13;
		y2=y3+length*y13;
		
		return;
	}	
	return;
}

double normal_dist(double mi, double sigma){
    double u1,u2,z;
    u1=((double)rand()+1)/(RAND_MAX+2);
    u2=((double)rand()+1)/(RAND_MAX+2);
    z=sqrt(-2.*log(u1))*cos(2*M_PI*u2);

    return mi+sigma*z;
}

int main(){
    srand(time(NULL));
    rand();
    double Nmax[4]={1e2,1e3,1e4,1e5};
    double D=1,dt=0.1,tmax=100;
    double sigdt=sqrt(2.*D*dt);
    int N=(tmax/dt);
    double x_exp,y_exp,x2_exp,y2_exp,xy_exp;
    double check[3]={0.1,1.0,5.0};
    double Dxx,Dxy,Dyy;
   
    for(int Nmaxi:Nmax){
        ofstream dxy("dxy"+to_string(Nmaxi)+".dat");
        int k=0;
        double dx,dy;
        vector<pair<double,double>> xy(Nmaxi);
        for(int i=0;i<Nmaxi;i++){
            xy[i]=make_pair(0.,0.);
        }
        
        for(int it=0;it<N;it++){
            for(int i=0;i<Nmaxi;i++){
                dx=normal_dist(0,sigdt);
                dy=normal_dist(0,sigdt);
                xy[i].first=xy[i].first+dx;
                xy[i].second=xy[i].second+dy;
            }
            x_exp=0;
            y_exp=0;
            x2_exp=0;
            y2_exp=0;
            xy_exp=0;
            for(int i=0;i<Nmaxi;i++){
                x_exp+=xy[i].first;
                y_exp+=xy[i].second;
                x2_exp+=xy[i].first*xy[i].first;
                y2_exp+=xy[i].second*xy[i].second;
                xy_exp+=xy[i].first*xy[i].second;
            }
            x_exp/=Nmaxi;
            y_exp/=Nmaxi;
            x2_exp/=Nmaxi;
            y2_exp/=Nmaxi;
            xy_exp/=Nmaxi;
            Dxx=(x2_exp-x_exp*x_exp)/2/dt/(it+1);
            Dxy=(xy_exp-x_exp*y_exp)/2/dt/(it+1);
            Dyy=(y2_exp-y_exp*y_exp)/2/dt/(it+1);
            dxy << it*dt << " " << Dxx << " " << Dxy << " " << Dyy << endl;
            if(check[k]==(double)it*dt && Nmaxi == 1e5){
                ofstream file("zad1_xy_"+to_string(it*dt)+".dat");
                k++;
                for(int i=0;i<Nmaxi;i++){
                    file << xy[i].first << " " << xy[i].second << endl;
                }
            }
        }
    }

    double xr=0,yr=0,Rr=5;
    double xa=3,ya=0,Ra[2]={0.1,0.5};
    double xs=-4.5,ys=0;
    double dn[3]={10*dt,50*dt,100*dt};
    double check2[4]={0.1,1,10,100};
    int k=0;
    tmax=1e3;
    N=(tmax/dt);
    double x1,y1,x2,y2;
    
    for(double dni:dn){
        for(double rai:Ra){
            vector<int> theta(Nmax[2]);
            vector<pair<double,double>> xy(Nmax[2]);
            ofstream filen("n_dn_"+to_string(dni)+"Ra_"+to_string(rai)+".dat");
            double dx,dy;
            int n,nnew;
            for(int it=0;it<N;it++){
                n=0;
                nnew=0;
                for(int i=0;i<Nmax[2];i++){
                    if(theta[i]==0 && nnew<dni){
                        theta[i]=1;
                        xy[i].first=xs;
                        xy[i].second=ys;
                        nnew++;
                    }
                    if(theta[i]==1){
                        x1=xy[i].first;
                        y1=xy[i].second;
                        dx=normal_dist(0,sigdt);
                        dy=normal_dist(0,sigdt);
                        x2=xy[i].first+dx;
                        y2=xy[i].second+dy;
                        double length=sqrt(x2*x2+y2*y2);
                        do{
                            particle_translation(x1,y1,x2,y2,xr,yr,Rr,xa,ya,rai,theta[i],length);
                        } while (length>1e-6);
                        xy[i].first=x2;
                        xy[i].second=y2;
                        if(theta[i]==1){n++;}
                    }
                }
                filen << it*dt << " " << n << endl;
                
                if(check2[k]==(double)it*dt && dni==100*dt && rai==0.5){
                    ofstream file("zad2_xy_"+to_string(it*dt)+".dat");
                    k++;
                    for(int i=0;i<Nmax[2];i++){
                        if(theta[i]==1){
                            file << xy[i].first << " " << xy[i].second << endl;
                        }
                    }
                }
                
            }
        }
    }
    
}