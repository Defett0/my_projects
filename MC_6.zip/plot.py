import matplotlib.pyplot as plt
import numpy as np

plt.rcParams['font.size']=18

# wczytywanie danych
xy1 = np.loadtxt("zad1_xy_0.100000.dat")
xy2 = np.loadtxt("zad1_xy_1.000000.dat")
xy3 = np.loadtxt("zad1_xy_5.000000.dat")

n1=np.loadtxt("n_dn_1.000000Ra_0.100000.dat")
n2=np.loadtxt("n_dn_1.000000Ra_0.500000.dat")
n3=np.loadtxt("n_dn_5.000000Ra_0.100000.dat")
n4=np.loadtxt("n_dn_5.000000Ra_0.500000.dat")
n5=np.loadtxt("n_dn_10.000000Ra_0.100000.dat")
n6=np.loadtxt("n_dn_10.000000Ra_0.500000.dat")

n_tab=[n1, n2, n3, n4, n5, n6]

xy21 = np.loadtxt("zad2_xy_0.100000.dat")
xy22 = np.loadtxt("zad2_xy_1.000000.dat")
xy23 = np.loadtxt("zad2_xy_10.000000.dat")
xy24 = np.loadtxt("zad2_xy_100.000000.dat")

xy_tab=[xy21,xy22,xy23,xy24]

#wykresy

plt.figure(figsize=(9,8))
plt.scatter(xy3[:,0],xy3[:,1],color='black',s=2)
plt.scatter(xy2[:,0],xy2[:,1],color='red',s=2)
plt.scatter(xy1[:,0],xy1[:,1],color='blue',s=2)
plt.ylim([-15,15])
plt.xlim([-15,15])
plt.ylabel("y")
plt.xlabel("x")
plt.grid()
plt.title("N$_{max}=10^5$")
plt.legend(['t=5.0','t=1.0','t=0.1'],markerscale=10,frameon=False)
plt.savefig("zad1xy.png")

name=''
m=np.zeros(3)
m2=np.zeros(3)
sig=np.zeros(3)
for i in range(4):
    plt.figure(figsize=(8,6))
    d = np.loadtxt("dxy100"+str(name)+".dat")
    plt.plot(d[:,0],d[:,1],color='black',lw=2)
    plt.plot(d[:,0],d[:,2],color='blue',lw=2)
    plt.plot(d[:,0],d[:,3],color='red',lw=2)
    plt.plot([0,100],[0,0],color='black',lw=1)
    plt.plot([0,100],[1,1],color='black',lw=1)
    plt.xlim([0,100])
    plt.title("N$_{max}$=10^"+str(i+2))
    plt.ylabel("D")
    plt.xlabel("t")
    plt.legend(['D$_{xx}$','D$_{xy}$','D$_{yy}$'],frameon=False)
    plt.grid()
    plt.savefig("D00"+name+".pdf")
    for j in range(3):
        m[j]=sum(d[:,j+1])/(d[:,j+1].size)
        m2[j]=sum(d[:,j+1]**2)/(d[:,j+1].size)
        sig[j]=np.sqrt((m2[j]-m[j]*m[j])/d[:,j+1].size)
        print("N$_{max}$=10^"+str(i+2)+" D"+str(j)+"="+str(m[j]))
        print("N$_{max}$=10^"+str(i+2)+" si"+str(j)+"="+str(sig[j])+"\n")
        
    name=name+str(0)

i=0
for n in n_tab:
    plt.figure(figsize=(8,6))
    plt.plot(n[:,0],n[:,1],color='black',lw=2)
    plt.subplots_adjust(left=0.15)
    plt.xlim([0,1000])
    plt.ylim(bottom=0)
    plt.grid()
    plt.xlabel("t")
    plt.ylabel("N")
    match i:
        case 0:
            plt.title("liczba aktywnych cząstek, $\omega=10$, $R_a=0.1$")
        case 1:
            plt.title("liczba aktywnych cząstek, $\omega=10$, $R_a=0.5$")
        case 2:
            plt.title("liczba aktywnych cząstek, $\omega=50$, $R_a=0.1$")
        case 3:
            plt.title("liczba aktywnych cząstek, $\omega=50$, $R_a=0.5$")
        case 4:
            plt.title("liczba aktywnych cząstek, $\omega=100$, $R_a=0.1$")
        case 5:
            plt.title("liczba aktywnych cząstek, $\omega=100$, $R_a=0.5$")
    plt.savefig("n"+str(i)+".pdf")
    i+=1

i=0
xc=np.linspace(-5,5,200)
y1c=np.sqrt(25-xc*xc)
y2c=-np.sqrt(25-xc*xc)

xa=np.linspace(2.5,3.5,30)
y1a=np.sqrt(0.25-(xa-3)*(xa-3))
y2a=-np.sqrt(0.25-(xa-3)*(xa-3))


for xy in xy_tab:
    plt.figure(figsize=(8,8))
    plt.scatter(xy[:,0],xy[:,1],color='black')
    plt.plot(xc,y1c,color='red',lw=5)
    plt.plot(xc,y2c,color='red',lw=5)
    plt.plot(xa,y1a,color='blue',lw=5)
    plt.plot(xa,y2a,color='blue',lw=5)
    plt.scatter(-4.5,0,s=100,color='orange')
    plt.grid()
    plt.xlabel("x")
    plt.ylabel("y")
    plt.title("t="+str(10**(i-1)))
    plt.savefig("zad2_xy"+str(i)+".pdf")
    i+=1

